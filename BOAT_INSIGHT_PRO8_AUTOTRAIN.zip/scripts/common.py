import math
FEATURE_SUFFIXES=['全国勝率','全国2連対率','全国3連対率','当地勝率','当地2連対率','当地3連対率','全国平均ST','モーター2連対率','モーター3連対率','ボート2連対率','ボート3連対率','年齢','F本数','L本数']
def num(v):
    try:
        f=float(str(v).replace('%','').strip())
        return f if math.isfinite(f) else float('nan')
    except (ValueError,TypeError):return float('nan')
def features(row,lane):
    values=[num(row.get(f'艇{lane}_{name}')) for name in FEATURE_SUFFIXES]
    values.extend([float(lane),num(row.get('レース場コード'))])
    return values
def race_key(row):return str(row.get('レースコード','')).strip()
