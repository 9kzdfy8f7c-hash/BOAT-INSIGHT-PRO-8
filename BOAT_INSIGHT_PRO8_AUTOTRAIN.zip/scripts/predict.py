import datetime as dt,json,io
from pathlib import Path
import numpy as np,pandas as pd,joblib,requests
from common import features,race_key
from train import rank_picks
ROOT=Path(__file__).resolve().parents[1]
def main():
    obj=joblib.load(ROOT/'models/model.joblib')
    today=dt.datetime.now(dt.timezone(dt.timedelta(hours=9))).date()
    url=f'https://boatracecsv.github.io/data/programs/race_cards/{today:%Y/%m/%d}.csv'
    r=requests.get(url,timeout=35);r.raise_for_status()
    rows=pd.read_csv(io.BytesIO(r.content),dtype={'レースコード':str,'レース場コード':str},low_memory=False).fillna('').to_dict('records')
    results={}
    for row in rows:
        code=race_key(row)
        if len(code)!=12:continue
        x=obj['imputer'].transform(np.asarray([features(row,i) for i in range(1,7)],dtype=float))
        scores=obj['model'].predict(x)
        top=rank_picks(scores)
        results[code]={'picks':[{'combination':'-'.join(map(str,p)),'score':round(prob,6)} for prob,p in top],
            'confidence':'未校正','method':'historical ML ranker'}
    if not results:raise RuntimeError('No races predicted; refusing empty publication')
    target=ROOT/'docs/data/predictions.json'
    target.write_text(json.dumps({'date':str(today),'generated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'races':results},ensure_ascii=False),encoding='utf-8')
    print('Predictions published',len(results))
if __name__=='__main__':main()
