"""Historical ML: train on past race cards; evaluate only on later races."""
import argparse, datetime as dt, io, json, itertools, os, time
from pathlib import Path
import numpy as np, pandas as pd, requests, joblib
from sklearn.ensemble import HistGradientBoostingRegressor
from common import features, race_key, FEATURE_SUFFIXES
ROOT=Path(__file__).resolve().parents[1]
BASE='https://boatracecsv.github.io/data/'
def fetch(kind,day,session):
    url=f'{BASE}{kind}/{day:%Y/%m/%d}.csv'
    try:
        r=session.get(url,timeout=18)
        if r.status_code==404:return []
        r.raise_for_status()
        df=pd.read_csv(io.BytesIO(r.content),dtype={'レースコード':str,'レース場コード':str},low_memory=False)
        if 'レースコード' not in df.columns:raise ValueError('missing race key')
        return df.fillna('').to_dict('records')
    except (requests.RequestException,ValueError) as e:
        print('SKIP',url,str(e)[:130],flush=True);return []
def winners(row):
    try: v=[int(str(row[f'{n}着_艇番']).strip()) for n in (1,2,3)]
    except (KeyError,ValueError,TypeError):return None
    return tuple(v) if len(set(v))==3 and all(1<=i<=6 for i in v) else None
def rank_picks(scores):
    w=np.exp(-np.clip(np.asarray(scores,dtype=float),-12,12))
    if not np.all(np.isfinite(w)) or w.sum()<=0:raise ValueError('invalid prediction scores')
    out=[]
    for a,b,c in itertools.permutations(range(6),3):
        p=(w[a]/w.sum())*(w[b]/(w.sum()-w[a]))*(w[c]/(w.sum()-w[a]-w[b]))
        out.append((float(p),(a+1,b+1,c+1)))
    return sorted(out,reverse=True)[:6]
def make_dataset(days,session):
    rows=[];labels={};seen=set()
    for day in days:
        cards=fetch('programs/race_cards',day,session)
        results={race_key(r):r for r in fetch('results/realtime',day,session)}
        for row in cards:
            code=race_key(row)
            if code in seen or len(code)!=12:continue
            target=winners(results.get(code,{}))
            if not target:continue
            seen.add(code);labels[code]=target
            for lane in range(1,7):
                position=target.index(lane)+1 if lane in target else 4
                rows.append((code,lane,features(row,lane),position))
    return rows,labels
def train_dataset(rows,labels,min_races=150):
    codes=sorted(labels)
    if len(codes)<min_races:raise RuntimeError(f'Insufficient actual races: {len(codes)} < {min_races}')
    cut=int(len(codes)*.8);train=set(codes[:cut]);test=set(codes[cut:])
    X=np.asarray([r[2] for r in rows],dtype=float)
    y=np.asarray([r[3] for r in rows],dtype=float)
    mask=np.array([r[0] in train for r in rows]);valid=~mask
    if not np.isfinite(X[mask]).any():raise RuntimeError('No numeric features in real race cards')
    from sklearn.impute import SimpleImputer
    imp=SimpleImputer(strategy='constant',fill_value=0,keep_empty_features=True)
    Xt=imp.fit_transform(X[mask]);Xv=imp.transform(X[valid])
    model=HistGradientBoostingRegressor(max_iter=160,max_leaf_nodes=20,l2_regularization=5,random_state=42)
    model.fit(Xt,y[mask]);yp=model.predict(Xv)
    predicted={}
    for row,score in zip((r for r,ok in zip(rows,valid) if ok),yp):predicted.setdefault(row[0],[]).append(float(score))
    hits=0;count=0;venue_stats={}
    for code,scores in predicted.items():
        if len(scores)!=6:continue
        top=[p for _,p in rank_picks(scores)]
        hit=labels[code] in top
        hits+=int(hit);count+=1
        venue=code[8:10];s=venue_stats.setdefault(venue,{'races':0,'hits':0});s['races']+=1;s['hits']+=int(hit)
    if count<30:raise RuntimeError('Too few holdout races')
    report={'trained':True,'training_races':len(train),'holdout_races':count,'top6_hits':hits,'top6_hit_rate':round(hits/count,6),
        'holdout_method':'time-ordered 80/20 by race code (date+venue+race)','features':FEATURE_SUFFIXES,
        'by_venue':venue_stats,'note':'Holdout is historical; not a guarantee of future accuracy. Predictions use uncalibrated scores.'}
    return {'model':model,'imputer':imp},report
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',default='2026-06-01');ap.add_argument('--end',default=(dt.date.today()-dt.timedelta(days=2)).isoformat());ap.add_argument('--max-days',type=int,default=90);args=ap.parse_args()
    start,end=map(dt.date.fromisoformat,(args.start,args.end))
    if end<start:raise ValueError('end before start')
    days=[start+dt.timedelta(days=i) for i in range((end-start).days+1)][-args.max_days:]
    with requests.Session() as session:rows,labels=make_dataset(days,session)
    bundle,report=train_dataset(rows,labels)
    report['date_range']=[str(days[0]),str(days[-1])]
    (ROOT/'models').mkdir(exist_ok=True)
    joblib.dump(bundle,ROOT/'models/model.joblib')
    (ROOT/'docs/data/training_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
