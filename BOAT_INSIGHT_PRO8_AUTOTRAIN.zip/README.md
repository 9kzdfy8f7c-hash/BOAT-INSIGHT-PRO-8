# BOAT INSIGHT PRO 8 — 自動学習・検証・予想配信

**このZIPに学習済みモデルは同梱されていません。** GitHub Actions実行後、実データ取得と学習が成功した場合にのみ学習済みモデルと検証レポートを生成します。エラー時は成功を装いません。

## GitHub設定
1. ZIPを展開し、すべてのファイル・フォルダをリポジトリのルートにアップロード。
2. Settings → Pages → Deploy from a branch → main /docs を選択。
3. Actions → Train ML and publish predictions → Run workflow。
4. 成功したら `docs/data/training_report.json` の trained=true、学習数・検証数・的中率を確認。
5. 学習モデルは `models/model.joblib` に保存され、予想は `docs/data/predictions.json` に公開されます。
6. 以降はGitHub Actionsのスケジュールで学習・予想更新（GitHub側の遅延はあり得ます）。

## 重要な制約
- 学習は実データが取得できる場合にのみ動作。データ取得失敗・学習失敗時は予想を捏造しません。
- サイトは表示中に30秒間隔でデータ確認。バックエンド予想更新は約30分ごと（GitHub Actionsの遅延あり）。
- 締切5分前の確定はブラウザを開いている端末のlocalStorageに保存。サーバーでの全端末共通確定ではありません。
- 星は実確率に校正されていないため「未評価」。オリ展は提供されている場のみ。
- 販売前にデータ再利用・商用利用の権利と運用条件を確認してください。
- GitHub Pagesのサイト設定はリポジトリ側で有効にする必要があります。

## 開発者用
`pip install -r requirements.txt` → `python scripts/train.py --start 2026-06-01 --max-days 90` → `python scripts/predict.py`。
テスト：`python -m unittest discover -s tests -v`。
