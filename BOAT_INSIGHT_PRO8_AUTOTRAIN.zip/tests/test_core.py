import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from common import features,race_key
from train import winners,rank_picks,train_dataset
class CoreTest(unittest.TestCase):
 def test_winners(self):
  self.assertEqual(winners({'1着_艇番':'1','2着_艇番':'4','3着_艇番':'2'}),(1,4,2))
  self.assertIsNone(winners({'1着_艇番':'1','2着_艇番':'1','3着_艇番':'2'}))
 def test_features(self):
  v=features({'レース場コード':'01','艇1_全国勝率':'7.88'},1)
  self.assertEqual(v[0],7.88);self.assertEqual(v[-2:], [1.0,1.0])
 def test_picks(self):
  p=rank_picks([1,2,3,4,5,6]);self.assertEqual(len(p),6)
  self.assertEqual(len(set(x[1] for x in p)),6)
 def test_small_dataset_refused(self):
  with self.assertRaises(RuntimeError):train_dataset([],{},min_races=150)
if __name__=='__main__':unittest.main()
